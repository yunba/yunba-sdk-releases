//
//  AppDelegate.h
//  YunbaDemo
//
//  Created by YunBa on 13-12-10.
//  Copyright (c) 2013年 SHENZHEN WEIZHIYUN TECHNOLOGY CO.LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (void)registerRemoteNotification;
- (void)unregisterRemoteNotification;
- (void)clearBadgeAndNotifications;
@end
