package io.yunba.examplewzp;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.xiaomi.mipush.sdk.ErrorCode;
import com.xiaomi.mipush.sdk.MiPushClient;
import com.xiaomi.mipush.sdk.MiPushCommandMessage;
import com.xiaomi.mipush.sdk.MiPushMessage;
import com.xiaomi.mipush.sdk.PushMessageReceiver;

import java.util.List;


/**
 * Created by coreVK on 16/9/12.
 */
public class XMessageReceiver extends PushMessageReceiver {
    public static final String TAG = "XMessageReceiver";

    public void showPushMessage(String msg) {
        MainActivity mainActivity = YunBaApplication.mainActivity;
        if (mainActivity != null) {
            Handler handler = mainActivity.getHandler();
            if (handler != null) {
                Message message = handler.obtainMessage();
                message.obj = msg;
                handler.sendMessageDelayed(message, 1L);
            }
        }
    }

    @Override
    public void onReceivePassThroughMessage(Context context, MiPushMessage miPushMessage) {
        super.onReceivePassThroughMessage(context, miPushMessage);
        showPushMessage("XM-onReceivePassThroughMessage" + miPushMessage.toString());
        Log.d(TAG, miPushMessage.toString());
    }

    @Override
    public void onNotificationMessageClicked(Context context, MiPushMessage miPushMessage) {
        super.onNotificationMessageClicked(context, miPushMessage);
        showPushMessage("XM-onNotificationMessageClicked" + miPushMessage.toString());
        Log.d(TAG, miPushMessage.toString());
    }

    @Override
    public void onNotificationMessageArrived(Context context, MiPushMessage miPushMessage) {
        super.onNotificationMessageArrived(context, miPushMessage);
        String string = "XM-onNotificationMessageArrived:"
                + " 摘要：" + miPushMessage.getDescription()
                + " 标题： " + miPushMessage.getTitle()
                + " MessageId: " + miPushMessage.getMessageId();
        showPushMessage(string);
        Log.d(TAG, string);
    }

    @Override
    public void onReceiveMessage(Context context, MiPushMessage miPushMessage) {
        super.onReceiveMessage(context, miPushMessage);
        showPushMessage("XM-onNotificationMessageArrived:"
                + " 摘要：" + miPushMessage.getDescription()
                + " 标题： " + miPushMessage.getTitle()
                + "MessageId: " + miPushMessage.getMessageId());
        Log.d(TAG, "XM-onNotificationMessageArrived:"
                + " 摘要：" + miPushMessage.getDescription()
                + " 标题： " + miPushMessage.getTitle()
                + "MessageId: " + miPushMessage.getMessageId());
    }

    @Override
    public void onReceiveRegisterResult(Context context, MiPushCommandMessage miPushCommandMessage) {
        super.onReceiveRegisterResult(context, miPushCommandMessage);
        showPushMessage("XM-onReceiveRegisterResult: "
                + " Category: " + miPushCommandMessage.getCategory()
                + " Command: " + miPushCommandMessage.getCommand()
                + " Reason: " + miPushCommandMessage.getReason()
                + " CommandArguments: " + miPushCommandMessage.getCommandArguments()
                + "ResultCode: " + miPushCommandMessage.getResultCode());
        Log.d(TAG, miPushCommandMessage.toString());

        String command = miPushCommandMessage.getCommand();
        List<String> arguments = miPushCommandMessage.getCommandArguments();
        String cmdArg1 = ((arguments != null && arguments.size() > 0) ? arguments.get(0) : null);
        String cmdArg2 = ((arguments != null && arguments.size() > 1) ? arguments.get(1) : null);
        if (MiPushClient.COMMAND_REGISTER.equals(command)) {
            if (miPushCommandMessage.getResultCode() == ErrorCode.SUCCESS) {
                Log.d(TAG, "cmdArg1" + cmdArg1);
            }
        }
    }

    @Override
    public void onCommandResult(Context context, MiPushCommandMessage miPushCommandMessage) {
        super.onCommandResult(context, miPushCommandMessage);
        showPushMessage("XM-onCommandResult" + miPushCommandMessage.toString());
        Log.d(TAG, miPushCommandMessage.toString());
    }


}
