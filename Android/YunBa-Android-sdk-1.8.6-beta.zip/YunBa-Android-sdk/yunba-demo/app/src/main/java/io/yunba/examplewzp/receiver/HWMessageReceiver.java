package io.yunba.examplewzp.receiver;

import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;


import com.huawei.android.pushagent.PushReceiver;
import com.huawei.android.pushagent.api.PushEventReceiver;

import io.yunba.examplewzp.DemoUtil;
import io.yunba.examplewzp.MainActivity;
import io.yunba.examplewzp.YunBaApplication;


/**
 * Created by coreVK on 16/9/12.
 */
public class HWMessageReceiver extends PushEventReceiver {

    public static final String TAG = "HWMessageReceiver";

    @Override
    public void onToken(Context context, String s, Bundle bundle) {
        String content = "获取token和belongId成功，token = " + s + ",belongId = " + bundle.getString("belongId");
        Log.d(TAG, content);
        showPushMessage(content);
    }

    @Override
    public boolean onPushMsg(Context context, byte[] bytes, Bundle bundle) {
        try {
            String content = "收到一条透传Push消息： " + new String(bytes, "UTF-8");
            Log.d(TAG, content);
            showPushMessage(content);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public void onEvent(Context context, Event event, Bundle bundle) {
        if (Event.NOTIFICATION_OPENED.equals(event) || Event.NOTIFICATION_CLICK_BTN.equals(event)) {
            int notifyId = bundle.getInt(BOUND_KEY.pushNotifyId, 0);
            if (0 != notifyId) {
                NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                manager.cancel(notifyId);
            }
            String content = "收到通知附加消息： " + bundle.getString(BOUND_KEY.pushMsgKey);
            Log.d(TAG, content);
            showPushMessage("onEvent: " + content);
        } else if (Event.PLUGINRSP.equals(event)) {
            final int TYPE_LBS = 1;
            final int TYPE_TAG = 2;
            int reportType = bundle.getInt(BOUND_KEY.PLUGINREPORTTYPE, -1);
            boolean isSuccess = bundle.getBoolean(BOUND_KEY.PLUGINREPORTRESULT, false);
            String message = "";
            if (TYPE_LBS == reportType) {
                message = "LBS report result :";
            } else if (TYPE_TAG == reportType) {
                message = "TAG report result :";
            }
            Log.d(TAG, message + isSuccess);
            showPushMessage(message + isSuccess);
        }
        super.onEvent(context, event, bundle);
    }

    public void showPushMessage(String msg) {
        MainActivity mainActivity = YunBaApplication.mainActivity;
        if (mainActivity != null) {
            Handler handler = mainActivity.getHandler();
            if (handler != null) {
                Message message = handler.obtainMessage();
                message.obj = msg;
                handler.sendMessage(message);
            }
        }
    }
}
