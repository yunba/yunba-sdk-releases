/** Automatically generated file. DO NOT MODIFY */
package io.yunba.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}